//
//  NCUserDefaults.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import Foundation

class NCUDConstants {
    
    public static let isLoggedIn = "isLoggedIn"
    public static let signinModel = "signinModel"
}

class NCUserDefaults {
    
    private static let ud = UserDefaults.standard
    
    class func saveUserDefaults(object : Any?, Key : String){
        ud.setValue(object, forKey: Key)
    }
    
    class func getUserDefaults(_ forKey: String) -> Any? {
        ud.object(forKey: forKey)
    }
    
    class func getUserDefaultsAsBool(_ forKey: String) -> Bool {
        ud.object(forKey: forKey) as? Bool ?? false
    }
    
    class func clearDataOnLogout() {
        NCUserDefaults.clearUserDefaults(NCUDConstants.signinModel)
        NCUserDefaults.clearUserDefaults(NCUDConstants.isLoggedIn)
    }
    
}

private extension NCUserDefaults {
    
    class func clearUserDefaults(_ key:String){
        ud.removeObject(forKey: key)
    }
}
