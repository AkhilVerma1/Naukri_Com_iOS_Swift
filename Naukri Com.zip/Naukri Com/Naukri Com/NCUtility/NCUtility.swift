//
//  NCUtility.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import UIKit

public struct NSAPIModelConstants {
    static let data = "data"
    static let code = "code"
    static let success = "success"
    static let email = "email"
    static let name = "name"
    static let skills = "skills"
    static let userRole = "userRole"
    static let createdAt = "createdAt"
    static let updatedAt = "updatedAt"
    static let id = "id"
    static let token = "token"
    static let message = "message"
    static let password = "password"
    static let confirmPassword = "confirmPassword"
    
}

class NCUtility {
    
    class func addPinnedContraints(subView:UIView,parentView:UIView,topConst:CGFloat = 0.0,bottomConst:CGFloat = 0.0,leadingConst:CGFloat = 0.0,trailingConst:CGFloat = 0.0){
        
        subView.translatesAutoresizingMaskIntoConstraints = false
        
        var contraints = [NSLayoutConstraint]()
        let topConstraint = NSLayoutConstraint(item: subView, attribute: .top, relatedBy: .equal, toItem: parentView, attribute: .top, multiplier: 1, constant: topConst)
        let bottomConstraint = NSLayoutConstraint(item: subView, attribute: .bottom, relatedBy: .equal, toItem: parentView, attribute: .bottom, multiplier: 1, constant: bottomConst)
        let leadingConstraint = NSLayoutConstraint(item: subView, attribute: .left, relatedBy: .equal, toItem: parentView, attribute: .left, multiplier: 1, constant: leadingConst)
        let trailingConstraint = NSLayoutConstraint(item: subView, attribute: .right, relatedBy: .equal, toItem: parentView, attribute: .right, multiplier: 1, constant: trailingConst)
        
        contraints.append(topConstraint)
        contraints.append(bottomConstraint)
        contraints.append(leadingConstraint)
        contraints.append(trailingConstraint)
        
        parentView.addConstraints(contraints)
    }
    
    class func isNilOrEmpty(string: String?) -> Bool {
        guard let value = string else { return true }

        return value.trimmingCharacters(in: .whitespaces).isEmpty
    }
    
    class func convertSwiftDictionaryToJsonString(dictionary :[String:Any]) ->String? {
        
        if let theJSONData = try? JSONSerialization.data(
            withJSONObject: dictionary,
            options: []) {
            if let theJSONText = String(data: theJSONData,
                                        encoding: .ascii) {
                
                print("JSON string = \(theJSONText)")
                return theJSONText
            }
        }
        
        return nil
    }
    
    class func utcStr(toLocalStr utcDate: String?, inputFormat: String?, outputFormat: String?) -> String? {
        let dateFormattor = DateFormatter()
        dateFormattor.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale
        dateFormattor.timeZone = NSTimeZone(abbreviation: "UTC") as TimeZone?
        dateFormattor.dateFormat = inputFormat
        guard let utcDate_ = utcDate else { return nil }
        let fromDate = dateFormattor.date(from: utcDate_)
        
        dateFormattor.timeZone = NSTimeZone.local
        dateFormattor.dateFormat = outputFormat
        var toDate: String? = nil
        if let fromDate = fromDate {
            toDate = dateFormattor.string(from: fromDate)
        }
        return toDate
    }
}

extension UITableView {
    
    func setEmptyMessage(_ message: String) {
        let messageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: self.bounds.size.width, height: self.bounds.size.height))
        messageLabel.text = message
        messageLabel.textColor = .black
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        messageLabel.sizeToFit()
        messageLabel.textColor = .systemBlue
        self.backgroundView = messageLabel
    }

}

extension String {
    
    func isValidEmail() -> Bool {
        let emailRegEx = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{1,4}$"
        let emailTest = NSPredicate(format:"SELF MATCHES[c] %@", emailRegEx)
        return emailTest.evaluate(with: self)
    }
    
    subscript(i: Int) -> String {
          return String(self[index(startIndex, offsetBy: i)])
      }
    
}

extension UIBarButtonItem {

    var isHidden: Bool {
        get {
            return tintColor == .clear
        }
        set {
            tintColor = newValue ? .clear : .systemBlue
            isEnabled = !newValue
            isAccessibilityElement = !newValue
        }
    }

}

extension UIApplication {
    
    class func topViewController(controller: UIViewController? = UIApplication.shared.windows.filter{$0.isKeyWindow}.first?.rootViewController) -> UIViewController? {
        
        if let navigationController = controller as? UINavigationController {
            return topViewController(controller: navigationController.visibleViewController)
        }
        
        if let tabController = controller as? UITabBarController {
            if let selected = tabController.selectedViewController {
                return topViewController(controller: selected)
            }
        }
        
        if let presented = controller?.presentedViewController {
            return topViewController(controller: presented)
        }
        
        return controller
    }
    
}

extension UIColor {
    
    static func random() -> UIColor {
        return UIColor(
            red:   .random(in: 0...1),
            green: .random(in: 0...1),
            blue:  .random(in: 0...1),
           alpha: 1.0
        )
    }
}
