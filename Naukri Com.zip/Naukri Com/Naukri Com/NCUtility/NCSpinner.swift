//
//  NCSpinner.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import UIKit

class NCSpinner {
    
    private var spinnerView: UIView?
    private var view: UIView?
    
    init(view:UIView) {
        self.view = view
    }
    
    func showSpinner() {

        guard let view_ = self.view else { return }
        
        let spinnerView = UIView.init(frame: view_.bounds)
        spinnerView.backgroundColor = UIColor(white: 0, alpha: 0.7)
        let view = UIActivityIndicatorView.init(style: UIActivityIndicatorView.Style.large)
        
        view.startAnimating()
        view.center = spinnerView.center
        
        DispatchQueue.main.async {
            spinnerView.addSubview(view)
            view_.addSubview(spinnerView)
        }
        
        self.spinnerView = spinnerView
    }
    
    func showSpinner(withDuration time:Double){
        
        guard let view_ = self.view else {
            return
        }
        
        let spinnerView = UIView.init(frame: view_.bounds)
        spinnerView.backgroundColor = UIColor(white: 0, alpha: 0.7)
        
        let view = UIActivityIndicatorView.init(style: UIActivityIndicatorView.Style.large)
        view.startAnimating()
        view.center = spinnerView.center
                
        DispatchQueue.main.asyncAfter(deadline: .now() + time) {
            spinnerView.addSubview(view)
            view_.addSubview(spinnerView)
        }
        
        self.spinnerView = spinnerView
    }
    
    func removeSpinner() {
        DispatchQueue.main.async {
            self.spinnerView?.removeFromSuperview()
            self.spinnerView = nil
        }
    }

    func removeSpinner(withDuration time:Double) {
        DispatchQueue.main.asyncAfter(deadline: .now() + time) {
            self.spinnerView?.removeFromSuperview()
            self.spinnerView = nil
        }
    }

}
