//
//  NCSignInViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import UIKit

class NCSignInViewController: UIViewController {
    
    @IBOutlet weak var uvContainer: UIView!

    private var spinner: NCSpinner?
    var emailID:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeView()
    }
    
}

private extension NCSignInViewController {
    
    func initializeView(){
        let signInView = NCSignInView(frame: self.uvContainer.bounds)
        signInView.delegate = self
        signInView.viewModel = getViewModel()
        signInView.setEmail()
        uvContainer.addSubview(signInView)
        NCUtility.addPinnedContraints(subView: signInView, parentView: self.uvContainer)
    }
    
    func getViewModel()-> NCSignInViewModel?{
        NCSignInViewModel(emailID)
    }
    
}

// MARK: -  NCSignInViewDelegate 

extension NCSignInViewController : NCSignInViewDelegate {
    
    func navigate(_ viewController: UIViewController, _ present: PresentationMode) {
        switch present {
        case .push:
            navigationController?.pushViewController(viewController, animated: true)
        case .present:
            navigationController?.present(viewController, animated: true, completion: nil)
        }
        
    }
    
    func showSpinner(_ show:Bool) {
        DispatchQueue.main.async { [self] in
            
            if show {
                if spinner == nil {
                    spinner = NCSpinner(view: view)
                }
                spinner?.showSpinner()
            } else {
                spinner?.removeSpinner()
            }
        }
        
    }
    
}
