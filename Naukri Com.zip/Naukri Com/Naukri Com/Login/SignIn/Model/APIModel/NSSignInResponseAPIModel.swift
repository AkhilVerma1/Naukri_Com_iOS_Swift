//
//  NSSignInResponseAPIModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import Foundation

class NSSignInResponseAPIModel: Codable {
    var data: NSSignInResponseAPIDataClass?
    var code: Int?
    var success: Bool?
    var message: String?

    init(_ dict:[AnyHashable:Any]?) {
        
        guard let dict_ = dict else {return }
        
        self.data = NSSignInResponseAPIDataClass(dict_[NSAPIModelConstants.data] as? [AnyHashable:Any])
        self.code = dict_[NSAPIModelConstants.code] as? Int
        self.success = dict_[NSAPIModelConstants.success] as? Bool
        self.message = dict_[NSAPIModelConstants.message] as? String
    }
}

// MARK: - DataClass
class NSSignInResponseAPIDataClass: Codable {
    var email, name, skills: String?
    var userRole: Int?
    var createdAt, updatedAt, id, token: String?

    init(_ dict:[AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
        
        self.email = dict_[NSAPIModelConstants.email] as? String
        self.name = dict_[NSAPIModelConstants.name] as? String
        self.skills = dict_[NSAPIModelConstants.skills] as? String
        self.userRole = dict_[NSAPIModelConstants.userRole] as? Int
        self.createdAt = dict_[NSAPIModelConstants.createdAt] as? String
        self.updatedAt = dict_[NSAPIModelConstants.updatedAt] as? String
        self.id = dict_[NSAPIModelConstants.id] as? String
        self.token = dict_[NSAPIModelConstants.token] as? String
    }
}
