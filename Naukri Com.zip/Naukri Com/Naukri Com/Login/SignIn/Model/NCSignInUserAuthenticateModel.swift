//
//  NCSignInUserAuthenticateModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import Foundation

struct NCSignInUserAuthenticateModel {
    let emailID: String?
    let password: String?
}
