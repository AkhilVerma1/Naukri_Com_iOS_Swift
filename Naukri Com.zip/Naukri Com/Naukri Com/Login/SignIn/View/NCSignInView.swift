//
//  NCSignInView.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import UIKit
import Lottie

protocol NCSignInViewDelegate : AnyObject {
    func navigate(_ viewController: UIViewController, _ present: PresentationMode)
    func showSpinner(_ show:Bool)
}

enum PresentationMode {
    case present
    case push
}

class NCSignInView : UIView {
    
    @IBOutlet var contentView: UIView!
    @IBOutlet weak var btnLoginOutlet: UIButton!
    @IBOutlet weak var animationView: AnimationView!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var lblError: UILabel!
    @IBOutlet weak var uvErrorViewContainer: UIView!
    
    @IBOutlet weak var btnShowPasswordOutlet: UIButton!
    @IBOutlet weak var errorViewHeightConstraint: NSLayoutConstraint!
    
    private let nibName = "NCSignInView"
    lazy var isPasswordVisible = false
    
    weak var delegate: NCSignInViewDelegate?
    var viewModel: NCSignInViewModel?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    @IBAction func btnShowPassword(_ sender: Any) {
        
        isPasswordVisible = !isPasswordVisible
        tfPassword.isSecureTextEntry = !isPasswordVisible
        btnShowPasswordOutlet.setImage(UIImage(systemName: isPasswordVisible ? "eye" : "eye.slash"), for: .normal)
    }
    
    
    @IBAction func btnLogin(_ sender: Any) {
        
        guard let emailID = tfEmail.text, emailID.isValidEmail() else {
            showError("Enter a Valid email id.")
            return
        }
        
        if tfPassword.text?.count ?? 0 > 6 {
            showError(nil)
            handleLogin()
        } else {
            showError("Password must be greater than 6 digits.")
        }
        
    }
    
    @IBAction func btnForgotPassword(_ sender: Any) {
        
        guard let text = tfEmail.text, text.isValidEmail() else {
            showError("Please enter a valid email id.!")
            return
        }
        
        showError(nil)
        
        delegate?.showSpinner(true)
        
        viewModel?.getResetPasswordToken(text) { [weak self] responseModel in
            
            if let responseModel_ = responseModel, responseModel_.success == true {
                
                self?.viewModel?.verifyToken(responseModel_.data?.token) { [weak self] success in
                    
                    self?.delegate?.showSpinner(false)
                    
                    if success ?? false {
                        guard let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "NCForgotPasswordViewController") as? NCForgotPasswordViewController else { return }
                        
                        viewController.token = responseModel_.data?.token
                        self?.delegate?.navigate(viewController, .present)
                    } else {
                        self?.showError("Something went wrong.")
                    }
                }
            } else {
                self?.delegate?.showSpinner(false)
                self?.lblError.text = responseModel?.message
                self?.errorViewHeightConstraint.constant = 20
            }
        }
        
    }
    
    func setEmail() {
        
        if let emailID = viewModel?.getEmailID() {
            tfEmail.text = emailID
            tfEmail.resignFirstResponder()
            tfPassword.becomeFirstResponder()
        }
    }
    
}

private extension NCSignInView {
    
    func commonInit(){
        Bundle.main.loadNibNamed(nibName, owner: self, options: nil)
        self.addSubview(contentView)
        contentView.frame = self.bounds
        contentView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        setupUI()
    }
    
    func setupUI() {
        setupAnimation()
        btnLoginOutlet.layer.borderWidth = 2
        btnLoginOutlet.layer.cornerRadius = 15
        btnLoginOutlet.layer.borderColor = UIColor.systemBlue.cgColor
        
        btnShowPasswordOutlet.imageView?.image = UIImage(systemName: "eye.slash")
    
        tfEmail.becomeFirstResponder()
    }
    
    func setupAnimation() {
        animationView.contentMode = .scaleToFill
        animationView.loopMode = .loop
        animationView.animationSpeed = 0.9
        animationView.play()
    }
    
    func handleLogin() {
        delegate?.showSpinner(true)
        
        let authModel = NCSignInUserAuthenticateModel(emailID: tfEmail.text, password: tfPassword.text)
        
        viewModel?.verify(authLoginModel: authModel) { [weak self] responseModel in
            
            self?.delegate?.showSpinner(false)

            guard let responseModel_ = responseModel, responseModel_.success == true else {
                self?.showError(responseModel?.message == nil ? "Something Went Wrong." : responseModel?.message ?? "")
                return
            }
                        
            guard let controller = NCSignInHelper.getHomeViewController(responseModel_.data?.userRole) as? NCDashboard else {
                self?.showError("Something Went Wrong.")
                return
            }
            
            self?.showError(nil)
            
            controller.userSigninResponseModel = responseModel_
            self?.delegate?.navigate(controller, .push)
            
            NCUserDefaults.saveUserDefaults(object: true, Key: NCUDConstants.isLoggedIn)
            NCUserDefaults.saveUserDefaults(object: try? JSONEncoder().encode(responseModel_), Key: NCUDConstants.signinModel)
            
        }
    }
    
    func showError(_ text: String?) {
        self.errorViewHeightConstraint.constant = (text == nil) ? 0 : 30
        self.lblError.text = text
    }
        
}
