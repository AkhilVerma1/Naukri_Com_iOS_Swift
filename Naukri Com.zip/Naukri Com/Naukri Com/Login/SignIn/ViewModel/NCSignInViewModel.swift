//
//  NCSignInViewModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import Foundation
import Alamofire

class NCSignInViewModel {
    
    private var emailID: String?
    
    init(_ emailID: String?) {
        self.emailID = emailID
    }
    
    func getEmailID() -> String? {
        emailID
    }
    
    func verify(authLoginModel: NCSignInUserAuthenticateModel?, _ completionHandler: @escaping (NSSignInResponseAPIModel?) -> Void) {
        
        let url = NCAPIURL.Login.authenticate
        let postData = NCSignInHelper.getPostDataForLogin(authLoginModel)
        
        AF.request(url, method: .post, parameters: postData, encoder: JSONParameterEncoder.default).response { response in
            switch response.result {
            
            case .success(let data):
                
                guard let data_ = data else {
                    completionHandler(nil)
                    return
                }
                
                do {
                    let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                    let responseAPIModel = NSSignInResponseAPIModel(json)
                    completionHandler(responseAPIModel)
                } catch {
                    completionHandler(nil)
                }
                
            default:
                completionHandler(nil)
            }
            
        }
        
    }
    
    func getResetPasswordToken(_ emailID: String,_ completion: @escaping (NCForgotPasswordResponseAPIModel?) -> Void) {
        
        let url = NCAPIURL.Login.getResetPasswordToken(emailID)
        
        AF.request(url, method: .get).response { response in
            
            guard let data_ = response.data else {
                completion(nil)
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                let responseAPIModel = NCForgotPasswordResponseAPIModel(json)
                completion(responseAPIModel)
            } catch {
                completion(nil)
            }
        }
        
    }
    
    func verifyToken(_ token: String?, _ completion: @escaping (Bool?) -> Void){
        
        let url = NCAPIURL.Login.getverifyPassword(token ?? "")
        
        AF.request(url, method: .get).response { response in
            
            guard let data_ = response.data else {
                completion(nil)
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                completion(json?["success"] as? Bool)
            } catch {
                completion(nil)
            }
        }
    }
}



