//
//  NCSignInHelper.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import UIKit

class NCSignInHelper {
    
    class func getPostDataForLogin(_ model: NCSignInUserAuthenticateModel?) -> [String:String] {
        
        guard let model_ = model else { return [:] }
        
        var postData = [String:String]()
        
        postData[Constants.email.rawValue] = model_.emailID
        postData[Constants.password.rawValue] = model_.password
        
        return postData
    }
    
    class func getHomeViewController(_ userRole:Int?) -> UIViewController? {
        let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
        return userRole == 0 ? storyboard.instantiateViewController(identifier: "NCDashboardViewController") as? NCDashboardViewController : storyboard.instantiateViewController(identifier: "NCTabbarViewController") as? NCTabbarViewController
    }
        
}

private extension NCSignInHelper {
    
    enum Constants : String{
        case email
        case password
    }
}
