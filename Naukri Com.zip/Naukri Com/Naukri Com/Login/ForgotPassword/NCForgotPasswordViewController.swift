//
//  NCForgotPasswordViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import UIKit
import Lottie

class NCForgotPasswordViewController: UIViewController {
    
    @IBOutlet weak var lockAnimationView: AnimationView!
    @IBOutlet weak var tfConfirmPassword: UITextField!
    @IBOutlet weak var btnResetPasswordOutlet: UIButton!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var btnShowPasswordOutlet: UIButton!
    @IBOutlet weak var btnShowConfirmPasswordOutlet: UIButton!

    lazy var isConfirmPasswordVisible = false
    lazy var isPasswordVisible = false
    
    private let viewModel = NCForgotPasswordViewModel()
    var token: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    @IBAction func btnShowConfirmPassword(_ sender: Any) {
        isConfirmPasswordVisible = !isConfirmPasswordVisible
        tfConfirmPassword.isSecureTextEntry = !isConfirmPasswordVisible
        btnShowConfirmPasswordOutlet.setImage(UIImage(systemName: isConfirmPasswordVisible ? "eye" : "eye.slash"), for: .normal)
    }
    
    @IBAction func btnShowPassword(_ sender: Any) {
        isPasswordVisible = !isPasswordVisible
        tfPassword.isSecureTextEntry = !isPasswordVisible
        btnShowPasswordOutlet.setImage(UIImage(systemName: isPasswordVisible ? "eye" : "eye.slash"), for: .normal)
    }
    
    @IBAction func btnResetPassword(_ sender: Any) {
        
        if NCUtility.isNilOrEmpty(string: tfPassword.text) {
            handleStatus(isError: true, text: "Please enter a Password.")
            return
        }
        
        if (tfPassword.text ?? "").count <= 6 {
            handleStatus(isError: true, text: "Password must be greater than 6 Characters.")
            return
        }
        
        guard tfPassword.text == tfConfirmPassword.text else {
            handleStatus(isError: true, text: "Password and confirm password should be same.!")
            return
        }
        
        viewModel.changePassword(tfPassword.text ?? "", token: token ?? "") { [weak self] responseModel in

            if responseModel?.success ?? false {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    self?.dismiss(animated: true, completion: nil)
                }
                self?.handleStatus(isError: false, text: "Successfully Changed")
            } else {
                self?.handleStatus(isError: true, text:  responseModel?.message ?? "Something Went Wrong.!")
            }
            
        }
        
    }
}

private extension NCForgotPasswordViewController {
    
    func setupUI(){
        setupAnimation()
        
        btnResetPasswordOutlet.layer.borderWidth = 2
        btnResetPasswordOutlet.layer.cornerRadius = 15
        btnResetPasswordOutlet.layer.borderColor = UIColor.systemBlue.cgColor
        
        tfPassword.becomeFirstResponder()
    }
    
    func setupAnimation(){
        lockAnimationView.contentMode = .scaleToFill
        lockAnimationView.loopMode = .loop
        lockAnimationView.animationSpeed = 1.2
        lockAnimationView.play()
    }
    
    func handleStatus(isError: Bool, text: String){
        lblStatus.isHidden = false
        lblStatus.text = text
        lblStatus.textColor = isError ? .systemRed : .systemGreen
    }
    
}

