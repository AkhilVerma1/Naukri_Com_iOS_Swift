//
//  NCForgotPasswordViewModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import Foundation
import Alamofire

class NCForgotPasswordViewModel {
    
    func changePassword(_ password:String, token:String, _ completion: @escaping (NCResetPasswordResponseAPIModel?) -> Void) {
        
        let url = NCAPIURL.Login.changePassword
        
        let postData = NCForgotPasswordHelper.getForgotPasswordPostData(password, token: token)
        
        AF.request(url, method: .post, parameters: postData, encoding: JSONEncoding.default).response { response in
            switch response.result {
            
            case .success(let data):
                
                guard let data_ = data else {
                    completion(nil)
                    return
                }
                
                do {
                    let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                    let responseAPIModel = NCResetPasswordResponseAPIModel(json)
                    completion(responseAPIModel)
                } catch {
                    completion(nil)
                }
                
            default:
                completion(nil)
            }
            
        }
    
    }}
