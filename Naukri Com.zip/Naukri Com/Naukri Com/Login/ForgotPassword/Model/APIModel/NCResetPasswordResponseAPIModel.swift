//
//  NCResetPasswordResponseAPIModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import Foundation

class NCResetPasswordResponseAPIModel {
    var data: NCResetPasswordResponseDataClass?
    var code: Int?
    var success: Bool?
    var message: String?

    init(_ dict: [AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
        
        self.data = NCResetPasswordResponseDataClass(dict_["data"] as? [AnyHashable:Any])
        self.code = dict_["code"] as? Int
        self.success = dict_["success"] as? Bool
        self.message = dict_["message"] as? String
    }
}

// MARK: - NCResetPasswordResponseDataClass

class NCResetPasswordResponseDataClass {
    
    var email, name, skills: String?
    var userRole: Int?
    var createdAt, updatedAt, id, token: String?

    init(_ dict: [AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
        
        self.email = dict_["email"] as? String
        self.name = dict_["name"] as? String
        self.skills = dict_["skills"] as? String
        self.userRole = dict_["userRole"] as? Int
        self.createdAt = dict_["createdAt"] as? String
        self.updatedAt = dict_["updatedAt"] as? String
        self.id = dict_["id"] as? String
        self.token = dict_["token"] as? String
    }
}
