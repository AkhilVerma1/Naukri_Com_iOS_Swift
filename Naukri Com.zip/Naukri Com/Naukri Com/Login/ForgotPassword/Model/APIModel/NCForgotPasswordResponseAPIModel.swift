//
//  NCForgotPasswordResponseAPIModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import Foundation

class NCForgotPasswordResponseAPIModel {
    
    var data:NCFPData?
    var code: Int?
    var success: Bool?
    var message: String?
    
    init(_ dict:[AnyHashable:Any]?) {
        guard let dict_ = dict else { return }
        
        self.data = NCFPData(dict_["data"] as? [AnyHashable:Any])
        self.code = dict_["code"] as? Int
        self.success = dict_["success"] as? Bool
        self.message = dict_["message"] as? String
    }
    
}

class NCFPData {
    
    var id: String?
    var token: String?
    var email: String?
    var valid: Bool?
    var updatedAt: String?
    var createdAt: String?
    
    init(_ dict:[AnyHashable:Any]?) {
        guard let dict_ = dict else { return }
        
        self.id = dict_["id"] as? String
        self.token = dict_["token"] as? String
        self.email = dict_["email"] as? String
        self.valid = dict_["valid"] as? Bool
        self.updatedAt = dict_["updatedAt"] as? String
        self.createdAt = dict_["createdAt"] as? String
    }
}
