//
//   NCForgotPasswordHelper.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import Foundation

class NCForgotPasswordHelper {
    
    class func getForgotPasswordPostData(_ password: String, token: String) -> [String:Any] {
        var postData = [String:Any]()
        postData[ForgotPasswordConstants.password.rawValue] = password
        postData[ForgotPasswordConstants.confirmPassword.rawValue] = password
        postData[ForgotPasswordConstants.token.rawValue] = token
        return postData
    }
}

extension NCForgotPasswordHelper {
    
    enum ForgotPasswordConstants : String {
        case password
        case confirmPassword
        case token
    }
}
