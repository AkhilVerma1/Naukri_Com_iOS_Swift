//
//  NCCreateUserHelper.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import Foundation
import Alamofire

class NCCreateUserHelper {
    
    class func getRegisterAPIData(_ userDetailsModel: NCCreateUserDetailsModel?) -> Parameters {
        
        guard let userDetailsModel_ = userDetailsModel else { return [:] }
        
        var postData = [String:Any]()
        
        postData[Constants.email.rawValue] = userDetailsModel_.email
        postData[Constants.userRole.rawValue] = userDetailsModel_.userRole
        postData[Constants.password.rawValue] = userDetailsModel_.password
        postData[Constants.confirmPassword.rawValue] = userDetailsModel_.confirmPassword
        postData[Constants.name.rawValue] = userDetailsModel_.name
        postData[Constants.skills.rawValue] = userDetailsModel_.skills

        return postData
    }
    
}

private extension NCCreateUserHelper {
    
    enum Constants: String {
        case email
        case userRole
        case password
        case confirmPassword
        case name
        case skills
    }
}
