//
//   NCCreateUserDetailsModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import Foundation

struct NCCreateUserDetailsModel {
    var email, password, confirmPassword, name, skills : String?
    var userRole: Int?
}
