//
//  NCCreateUserResponseAPIModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import Foundation

class NCCreateUserResponseAPIModel {
    var data: UserInfo?
    var code: Int?
    var success: Bool?
    var message: String?
    var errors: [[String:String]]?

    init(_ dict: [AnyHashable:Any]?) {
        guard let dict_ = dict else { return }
        
        self.data = UserInfo(dict_["data"] as? [AnyHashable:Any])
        self.code = dict_["code"] as? Int
        self.success = dict_["success"] as? Bool
        self.message = dict_["message"] as? String
        self.errors = dict_["errors"] as? [[String:String]]
    }
}

// MARK: - UserInfo

class UserInfo {
    var id, email: String?
    var userRole: Int?
    var name, skills, updatedAt, createdAt: String?
    var token: String?

    init(_ dict:[AnyHashable:Any]?) {
        guard let dict_ = dict else { return }
        
        self.id = dict_["id"] as? String
        self.email = dict_["email"] as? String
        self.userRole = dict_["userRole"] as? Int

        self.name = dict_["name"] as? String
        self.skills = dict_["skills"] as? String
        self.updatedAt = dict_["updatedAt"] as? String
        self.createdAt = dict_["createdAt"] as? String
        self.token = dict_["token"] as? String

    }
}
