//
//  NCCreateUserViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import UIKit

class NCCreateUserViewController: UIViewController {

    @IBOutlet var uvContainer: UIView!
    
    private var spinner: NCSpinner?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeView()
    }
    
}

private extension NCCreateUserViewController {
    
    func initializeView(){
        let createUserView = NCCreateUserView(frame: self.uvContainer.bounds)
        createUserView.delegate = self
        createUserView.viewModel = getViewModel()
        uvContainer.addSubview(createUserView)
        NCUtility.addPinnedContraints(subView: createUserView, parentView: self.uvContainer)
    }
    
    func getViewModel()-> NCCreateUserViewModel?{
        NCCreateUserViewModel()
    }
    
}


// MARK: -  NCCreateUserViewDelegate 

extension NCCreateUserViewController: NCCreateUserViewDelegate {
    
    func navigate(_ viewController: UIViewController) {
        navigationController?.pushViewController(viewController, animated: true)
    }
    
    func showSpinner(_ show:Bool) {
        if show {
            if spinner == nil {
                spinner = NCSpinner(view: view)
            }
            spinner?.showSpinner()
        } else {
            spinner?.removeSpinner()
        }
    }
}



