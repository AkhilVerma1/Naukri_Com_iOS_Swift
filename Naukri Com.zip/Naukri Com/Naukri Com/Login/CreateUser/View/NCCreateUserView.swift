//
//  NCCreateUserView.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import UIKit

protocol NCCreateUserViewDelegate: AnyObject {
    func showSpinner(_ show:Bool)
    func navigate(_ viewController: UIViewController)
}

class NCCreateUserView : UIView {
    
    @IBOutlet var contentView: UIView!
    @IBOutlet weak var btnCreateAccountOutlet: UIButton!
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var tfComfirmPassword: UITextField!
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var tfSkills: UITextField!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var lblError: UILabel!
    @IBOutlet weak var btnShowPasswordOutler: UIButton!
    @IBOutlet weak var btnShowConfirmPasswordOutler: UIButton!

    var selectedSegment = 0
    var viewModel: NCCreateUserViewModel?
    weak var delegate: NCCreateUserViewDelegate?
    private let nibName = "NCCreateUserView"
    lazy var isConfirmPasswordVisible = false
    lazy var isPasswordVisible = false

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    @IBAction func btnCreateAccount(_ sender: Any) {
        lblError.text = nil
        if let customError = getCustomError() { lblError.text = customError }
        else { createAccount() }
    }
    
    @IBAction func btnShowConfirmPassword(_ sender: Any) {
        isConfirmPasswordVisible = !isConfirmPasswordVisible
        tfComfirmPassword.isSecureTextEntry = !isConfirmPasswordVisible
        btnShowConfirmPasswordOutler.setImage(UIImage(systemName: isConfirmPasswordVisible ? "eye" : "eye.slash"), for: .normal)
    }
    
    @IBAction func btnShowPassword(_ sender: Any) {
        isPasswordVisible = !isPasswordVisible
        tfPassword.isSecureTextEntry = !isPasswordVisible
        btnShowPasswordOutler.setImage(UIImage(systemName: isPasswordVisible ? "eye" : "eye.slash"), for: .normal)
    }
    
}

private extension NCCreateUserView {
    
    func commonInit(){
        Bundle.main.loadNibNamed(nibName, owner: self, options: nil)
        self.addSubview(contentView)
        contentView.frame = self.bounds
        contentView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        setupUI()
    }
    
    func setupUI(){
        btnCreateAccountOutlet.layer.borderWidth = 2
        btnCreateAccountOutlet.layer.cornerRadius = 15
        btnCreateAccountOutlet.layer.borderColor = UIColor.systemBlue.cgColor
        tfName.becomeFirstResponder()
    }
    
    func createAccount(){
        
        delegate?.showSpinner(true)
        
        let userDetails = NCCreateUserDetailsModel(email: tfEmail.text, password: tfPassword.text, confirmPassword: tfComfirmPassword.text, name: tfName.text, skills: tfSkills.text, userRole: segmentController.selectedSegmentIndex)
        
        viewModel?.createUser(userDetails) { [weak self] responseModel in
            
            self?.delegate?.showSpinner(false)

            guard let responseModel_ = responseModel, responseModel_.success == true, let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "NCSignInViewController") as? NCSignInViewController else {
                self?.lblError.textColor = .systemRed
                self?.handleAPIException(responseModel?.errors, message: responseModel?.message)
                
                return
            } 
            
            viewController.emailID = responseModel_.data?.email
            
            self?.lblError.text = "User Created Successfully"
            self?.lblError.textColor = .systemGreen
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self?.delegate?.navigate(viewController)
            }
        }
    }
    
    func handleAPIException(_ errors: [[String:String]]?, message: String? ){
        
        guard let errors_ = errors else {
            self.lblError.text = message ?? "Something went wrong."
            return
        }
        
        for error in errors_ {
            if let err = error.values.first {
                lblError.text = "\(lblError.text ?? "") \(err) \n"
            }
        }
        
    }
    
    func getCustomError() -> String? {
        
        if NCUtility.isNilOrEmpty(string: tfName.text) {
            return "Please enter your name.!"
        } else if !(tfEmail.text?.isValidEmail() ?? false) {
            return "Please enter a valid email.!"
        } else if NCUtility.isNilOrEmpty(string: tfPassword.text) {
            return "Please enter your password.!"
        } else if tfPassword.text?.count ?? 0 <= 6 {
            return "Password must be greater than 6 characters.!"
        }  else if tfComfirmPassword.text != tfPassword.text {
            return "ConfirmPassword and Password are not same.!"
        } else if segmentController.selectedSegmentIndex == 1 && NCUtility.isNilOrEmpty(string: tfSkills.text) {
            return "Pleae enter your Skills.!"
        }

        return nil
    }
    
}
