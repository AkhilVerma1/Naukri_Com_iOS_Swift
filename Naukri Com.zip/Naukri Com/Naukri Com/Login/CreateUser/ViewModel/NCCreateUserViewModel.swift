//
//  NCCreateUserViewModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 29/08/21.
//

import Foundation
import Alamofire

class NCCreateUserViewModel {
    
    func createUser(_ userDetailsModel: NCCreateUserDetailsModel?, _ completionHandler: @escaping (NCCreateUserResponseAPIModel?) -> Void){
        
        let url = NCAPIURL.Login.register
        let postData = NCCreateUserHelper.getRegisterAPIData(userDetailsModel)
        
        AF.request(url, method: .post, parameters: postData, encoding: JSONEncoding.default).responseJSON { response in

            guard let data_ = response.data else {
                completionHandler(nil)
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                let responseAPIModel = NCCreateUserResponseAPIModel(json)
                completionHandler(responseAPIModel)
            } catch {
                completionHandler(nil)
            }
            
        }
    }
    
}
