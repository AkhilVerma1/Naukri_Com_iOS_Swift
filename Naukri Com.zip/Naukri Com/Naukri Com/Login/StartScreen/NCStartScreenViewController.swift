//
//  NCViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import UIKit
import Lottie

class NCStartScreenViewController: UIViewController {
    
    @IBOutlet weak var animationView: AnimationView!
    @IBOutlet weak var uvSignIn: UIView!
    @IBOutlet weak var uvCreateAccount: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        animationView.play()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if isUserLogedIn() {
            guard let data = getSiginModelData(), let siginModel = try? JSONDecoder().decode(NSSignInResponseAPIModel.self, from: data), let viewController = NCSignInHelper.getHomeViewController(siginModel.data?.userRole) as? NCDashboard else { return }
            
            viewController.userSigninResponseModel = siginModel
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
    
    @IBAction func btnCreateAccount(_ sender: Any) {
        guard let viewController = self.storyboard?.instantiateViewController(identifier: "NCCreateUserViewController") as? NCCreateUserViewController else { return }
        
        navigationController?.pushViewController(viewController, animated: true)
    }
    
    @IBAction func btnSignIn(_ sender: Any) {
        guard let viewController = self.storyboard?.instantiateViewController(identifier: "NCSignInViewController") as? NCSignInViewController else { return }
        
        navigationController?.pushViewController(viewController, animated: true)
    }
    
}

private extension NCStartScreenViewController {
    
    func setupUI(){
        uvSignIn.layer.cornerRadius = 20
        uvCreateAccount.layer.cornerRadius = 20
        
        uvSignIn.layer.borderWidth = 2
        uvCreateAccount.layer.borderWidth = 2
        
        uvSignIn.layer.borderColor = UIColor.systemBlue.cgColor
        uvCreateAccount.layer.borderColor = UIColor.systemBlue.cgColor
        setupAnimation()
    }
    
    func setupAnimation(){
        animationView.contentMode = .scaleAspectFill
        animationView.loopMode = .loop
        animationView.animationSpeed = 0.5
        animationView.play()
    }
    
    func isUserLogedIn() -> Bool {
        NCUserDefaults.getUserDefaultsAsBool(NCUDConstants.isLoggedIn)
    }
    
    func getSiginModelData() -> Data? {
        NCUserDefaults.getUserDefaults(NCUDConstants.signinModel) as? Data
    }
}
