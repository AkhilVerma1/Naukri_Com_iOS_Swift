//
//  NCTabbarViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import UIKit

protocol NCDashboard : UIViewController {
    var userSigninResponseModel : NSSignInResponseAPIModel? {get set}
}

class NCTabbarViewController: UITabBarController, NCDashboard {
    
    var userSigninResponseModel : NSSignInResponseAPIModel?
    
    var jobHistoryViewController: NCJobHistoryViewController?

    override func viewDidLoad() {
        super.viewDidLoad()

        setupNavigationController()
        setupViewControllers()
    }
    
    func setupNavigationController() {
        self.navigationItem.setHidesBackButton(true, animated:true)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    func setupViewControllers(){
        let dashboardViewController = viewControllers?.first?.children.first as? NCDashboardViewController
        jobHistoryViewController = viewControllers?.last?.children.first as? NCJobHistoryViewController
        dashboardViewController?.userSigninResponseModel = userSigninResponseModel
        jobHistoryViewController?.token = userSigninResponseModel?.data?.token
        
        dashboardViewController?.delegate = self
        

    }

}

extension NCTabbarViewController : NCDashboardViewControllerDelegate {
    
    func refreshView() {
        jobHistoryViewController?.refreshData()
    }
    
}
