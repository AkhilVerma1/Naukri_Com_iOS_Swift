//
//  NCJobHistoryViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import UIKit

class NCJobHistoryViewController: UIViewController {
    
    @IBOutlet weak var uvContainer: UIView!
    
    private var spinner: NCSpinner?
    private var viewModel: NCJobHistoryViewModel?
    
    var jobHistoryView: NCJobHistoryView?
    var token: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeView()
    }
    
    func refreshData() {
        self.showLoading(true)
        viewModel?.fetchData()
    }
    
}

private extension NCJobHistoryViewController {
    
    func initializeView(){
        jobHistoryView = NCJobHistoryView(frame: self.uvContainer.bounds)
        jobHistoryView?.delegate = self
        viewModel = getViewModel()
        jobHistoryView?.setupViewModel(viewModel)
        
        if let jobHistoryView_ = jobHistoryView {
            uvContainer.addSubview(jobHistoryView_)
            NCUtility.addPinnedContraints(subView: jobHistoryView_, parentView: self.uvContainer)
        }
    }
    
    func getViewModel() -> NCJobHistoryViewModel {
        NCJobHistoryViewModel(token)
    }
    
    
}

extension NCJobHistoryViewController : NCJobHistoryViewDelegate {
    
    func showLoading(_ show: Bool) {
        
        DispatchQueue.main.async { [self] in
            
            if show {
                if spinner == nil {
                    spinner = NCSpinner(view: view)
                }
                spinner?.showSpinner()
            } else {
                spinner?.removeSpinner()
            }
        }
    }
    
    func navigate(_ viewController: UIViewController, _ present: PresentationMode) {
        switch present {
        case .present:
            self.present(viewController, animated: true, completion: nil)
        case .push:
            navigationController?.pushViewController(viewController, animated: true)
        }
    }
}
