//
//  NCJobHistoryView.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import UIKit

protocol NCJobHistoryViewDelegate: AnyObject {
    func showLoading(_ show: Bool)
    func navigate(_ viewController: UIViewController, _ present: PresentationMode)
}

class NCJobHistoryView : UIView {
    
    @IBOutlet var contentView: UIView!
    @IBOutlet weak var jobHistoryTableView: UITableView!
    
    private let nibName = "NCJobHistoryView"
    
    weak var delegate: NCJobHistoryViewDelegate?
    private var viewModel: NCJobHistoryViewModel?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    func setupViewModel(_ viewModel: NCJobHistoryViewModel?) {
        self.viewModel = viewModel
        self.viewModel?.delegate = self
        delegate?.showLoading(true)
        self.viewModel?.fetchData()
    }
    
}

private extension NCJobHistoryView {
    
    func commonInit(){
        Bundle.main.loadNibNamed(nibName, owner: self, options: nil)
        self.addSubview(contentView)
        contentView.frame = self.bounds
        contentView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        setupTableView()
    }
    
    func setupTableView() {
        jobHistoryTableView.delegate = self
        jobHistoryTableView.dataSource = self
        jobHistoryTableView.register(UINib(nibName: NCDashboardTableViewCell.nibName, bundle: nil), forCellReuseIdentifier: NCDashboardTableViewCell.nibName)
    }
    
    func reloadTableView(){
        DispatchQueue.main.async {
            self.jobHistoryTableView.reloadData()
        }
    }
}

extension NCJobHistoryView: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel?.getTotalRows() ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let view = tableView.dequeueReusableCell(withIdentifier: NCDashboardTableViewCell.nibName) as? NCDashboardTableViewCell else { return UITableViewCell() }
        
        let detailsModel = NCAvaliableJobsDetailsModel(title: viewModel?.getTitle(indexPath), description: viewModel?.getDescription(indexPath), location: viewModel?.getLocation(indexPath), createdAt: viewModel?.createdAt(indexPath))
        
        view.setData(detailsModel, indexPath)
        view.selectionStyle = .none
        
        return view
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let viewController = UIStoryboard(name: "Dashboard", bundle: nil).instantiateViewController(identifier: "NCDashboardJobDetailsViewController") as? NCDashboardJobDetailsViewController else { return }
        
        viewController.avaliableJobsDetailsModel = NCAvaliableJobsDetailsModel(title: viewModel?.getTitle(indexPath), description: viewModel?.getDescription(indexPath), location: viewModel?.getLocation(indexPath), createdAt: viewModel?.createdAt(indexPath))
        
        viewController.disableApplyButton = true
        
        delegate?.navigate(viewController, .present)
    }
    
}

extension NCJobHistoryView: NCJobHistoryViewModelDelegate {
    
    func dataFetched(_ success: Bool) {
        delegate?.showLoading(false)
        success ? reloadTableView() : jobHistoryTableView.setEmptyMessage("No Records Found.")
    }

}



