//
//  NCJobHistoryViewModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation

protocol NCJobHistoryViewModelDelegate :AnyObject {
    func dataFetched(_ success: Bool)
}

class NCJobHistoryViewModel {
    
    private var appliedJobsResponseAPIModel: NCAppliedJobsResponseAPIModel?
    private var token: String?
    
    weak var delegate: NCJobHistoryViewModelDelegate?
    
    init(_ token: String?) {
        self.token = token
    }
    
    func fetchData() {
        NCDashboardJobDetailsFetcher.shared.fetchAppliedJobs(token) { [weak self] responseModel in
            if let responseModel_ = responseModel {
                self?.appliedJobsResponseAPIModel = responseModel_
                self?.delegate?.dataFetched(true)
            } else {
                self?.delegate?.dataFetched(false)
            }
        }
    }
    
    func getTotalRows() -> Int {
        appliedJobsResponseAPIModel?.data.count ?? 0
    }
    
    func getLocation(_ indexPath: IndexPath) -> String {
        appliedJobsResponseAPIModel?.data[indexPath.row].location ?? ""
    }
    
    func getTitle(_ indexPath: IndexPath) -> String {
        appliedJobsResponseAPIModel?.data[indexPath.row].title ?? ""
    }
    
    func getDescription(_ indexPath: IndexPath) -> String {
        appliedJobsResponseAPIModel?.data[indexPath.row].datumDescription ?? ""
    }
    
    func createdAt(_ indexPath: IndexPath) -> String  {
        appliedJobsResponseAPIModel?.data[indexPath.row].createdAt ?? ""
    }
    
}

