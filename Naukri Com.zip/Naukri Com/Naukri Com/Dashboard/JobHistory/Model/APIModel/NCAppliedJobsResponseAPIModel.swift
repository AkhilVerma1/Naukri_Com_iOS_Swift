//
//  NCAppliedJobsResponseAPIModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation

class NCAppliedJobsResponseAPIModel {
    
    var data = [NCAppliedJobsResponseAPIModelDatum]()
    var code: Int?
    var success: Bool?

    init(_ dict: [AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
        
        self.code = dict_["code"] as? Int
        self.success = dict_["success"] as? Bool
            
        for data_ in dict_["data"] as? [[AnyHashable:Any]] ?? [] {
            self.data.append(NCAppliedJobsResponseAPIModelDatum(data_))
        }

    }
}

// MARK: - NCAppliedJobsResponseAPIModelDatum

class NCAppliedJobsResponseAPIModelDatum {
    
    var title, datumDescription, location, createdAt: String?
    var updatedAt, id: String?

    init(_ dict: [AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
        
        self.title = dict_["title"] as? String
        self.datumDescription = dict_["description"] as? String
        self.location = dict_["location"] as? String
        self.createdAt = dict_["createdAt"] as? String
        self.updatedAt = dict_["updatedAt"] as? String
        self.id = dict_["id"] as? String
    }
}

