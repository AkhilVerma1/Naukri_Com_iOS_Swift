//
//  NCDashboardJobCandidatesTableViewCell.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import UIKit

class NCDashboardJobCandidatesTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblSkills: UILabel!
    @IBOutlet weak var lblImage: UILabel!
    @IBOutlet weak var iv: UIImageView!
    
    static let nibName = "NCDashboardJobCandidatesTableViewCell"
    
    static let colors: [UIColor] = [.systemYellow, .systemOrange, .systemTeal, .systemOrange, .systemBlue]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
    private func setupUI(){
        iv.backgroundColor = UIColor.random()
        iv.layer.borderWidth = 2
        iv.layer.cornerRadius = 25
        iv.layer.borderColor = UIColor.gray.cgColor
        }
    
    func setData(email:String?, name:String?, skills: String?) {
        lblName.text = name
        lblEmail.text = "Email: \(email ?? "")"
        lblSkills.text = "Skills: \(skills ?? "")"
        lblImage.text = (name?.uppercased() ?? "")[0]
    }
    
}
