//
//  NCDashboardJobDetailsFetcher.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation
import Alamofire

class NCDashboardJobDetailsFetcher {
    
    public static let shared = NCDashboardJobDetailsFetcher()
    
    func applyToJob(_ jobId: String?, token:String?, _ completionHandler: @escaping (Bool?) -> Void) {
        
        let url = NCAPIURL.Candidates.applyForJob
        let postData = getApplyToJobPostData(jobId)
        
        let headers : HTTPHeaders = getHeader(token)
        
        AF.request(url, method: .post, parameters: postData, encoding: JSONEncoding.default, headers: headers).responseJSON { response in
            
            guard let data_ = response.data else {
                completionHandler(nil)
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                completionHandler(json?["success"] as? Bool)
            } catch {
                completionHandler(nil)
            }
            
        }
        
    }
    
    func fetchAppliedJobs(_ token: String?, completion: @escaping (NCAppliedJobsResponseAPIModel?) -> Void) {
        
        let url = NCAPIURL.Candidates.alreadyAppliedJob
        
        let headers : HTTPHeaders = getHeader(token)
        
        AF.request(url, method: .get, headers: headers).response { response in
            
            guard let data_ = response.data else {
                completion(nil)
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                completion(NCAppliedJobsResponseAPIModel(json))
                
            } catch {
                completion(nil)
            }
        }
        
    }
    
    func createJob(_ model: NCJobPostParamsModel?, _  completionHandler: @escaping (Bool?, String?, [[String:String]]?) -> Void) {
        
        let url = NCAPIURL.Jobs.createJob
        let postData = getCreateJobPostData(model)
        let headers : HTTPHeaders = getHeader(model?.token)
        
        AF.request(url, method: .post, parameters: postData, encoding: JSONEncoding.default, headers: headers).responseJSON { response in
            
            guard let data_ = response.data else { completionHandler(false, nil, nil); return }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                completionHandler(json?["success"] as? Bool, json?["message"] as? String, json?["errors"] as? [[String:String]])
            } catch {
                completionHandler(false,nil, nil)
            }
            
        }
    }
    
    
    func fetchJobCandidates(_ token: String?, jobId: String?, completion: @escaping (NCDashboardJobCandidatesResponseModel?) -> Void) {
        
        let url = NCAPIURL.Recruiters.getOneJobCandidates(jobId ?? "")
        let headers : HTTPHeaders = getHeader(token)
        
        AF.request(url, method: .get, headers: headers).response { response in
            
            guard let data_ = response.data else { completion(nil); return }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                completion(NCDashboardJobCandidatesResponseModel(json))
                
            } catch {
                completion(nil)
            }
        }
        
    }
    
}

private extension NCDashboardJobDetailsFetcher {
    
    func getApplyToJobPostData(_ jobId: String?) -> Parameters {
        var postData = [String:Any]()
        postData["jobId"] = jobId
        return postData
    }
    
    func getCreateJobPostData(_ model: NCJobPostParamsModel?) -> Parameters {
        var postData = [String:String]()
        
        postData["title"] = model?.title
        postData["description"] = model?.description
        postData["location"] = model?.location
        
        return postData
        
    }
    
    func getHeader(_ token: String?) -> HTTPHeaders {
        ["Authorization" : token ?? ""]
    }
}
