//
//  NCDashboardView.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import UIKit
import ViewAnimator

protocol NCDashboardViewDelegate {
    func showLoading(_ show:Bool)
    func refresh()
    func navigate(_ viewController: UIViewController, _ present: PresentationMode)
}

class NCDashboardView: UIView {
    
    @IBOutlet var contentView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    private let nibName = "NCDashboardView"
    
    var delegate: NCDashboardViewDelegate?
    private var viewModel: NCDashboardViewModel?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    func setupViewModel(_ viewModel: NCDashboardViewModel?){
        self.viewModel = viewModel
        self.viewModel?.delegate = self
        self.viewModel?.fetchData()
    }
    
}

private extension NCDashboardView {
    
    func commonInit(){
        Bundle.main.loadNibNamed(nibName, owner: self, options: nil)
        self.addSubview(contentView)
        contentView.frame = self.bounds
        contentView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        setupTableView()
    }
    
    func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: NCDashboardTableViewCell.nibName, bundle: nil), forCellReuseIdentifier: NCDashboardTableViewCell.nibName)
    }
    
    func reloadTableView(){
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
}

extension NCDashboardView: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel?.getTotalRows() ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let view = tableView.dequeueReusableCell(withIdentifier: NCDashboardTableViewCell.nibName) as? NCDashboardTableViewCell else { return UITableViewCell() }
        
        let detailsModel = NCAvaliableJobsDetailsModel(title: viewModel?.getTitle(indexPath), description: viewModel?.getDescription(indexPath), location: viewModel?.getLocation(indexPath), createdAt: viewModel?.createdAt(indexPath))

        let animation = AnimationType.from(direction: .bottom, offset: 80.0)
        let zoomAnimation = AnimationType.zoom(scale: 0.4)
        view.animate(animations: [animation, zoomAnimation], usingSpringWithDamping :ViewAnimatorConfig.springDampingRatio, initialSpringVelocity: 0.2)
        
        view.setData(detailsModel, indexPath)
        view.selectionStyle = .none
        
        return view
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if viewModel?.getUserRole() == .candidate {
            
            guard let viewController = UIStoryboard(name: "Dashboard", bundle: nil).instantiateViewController(identifier: "NCDashboardJobDetailsViewController") as? NCDashboardJobDetailsViewController else { return }
            
            viewController.avaliableJobsDetailsModel = NCAvaliableJobsDetailsModel(title: viewModel?.getTitle(indexPath), description: viewModel?.getDescription(indexPath), location: viewModel?.getLocation(indexPath), createdAt: viewModel?.createdAt(indexPath), jobID: viewModel?.getJobID(indexPath))
            
            viewController.token = viewModel?.getToken()
            viewController.delegate = self
            delegate?.navigate(viewController, .present)
            
        } else {
            NCDashboardJobDetailsFetcher.shared.fetchJobCandidates(viewModel?.getToken(), jobId: viewModel?.getJobID(indexPath)) { [weak self] responseModel in
                
                if responseModel?.success == true {
                    guard let viewController = UIStoryboard(name: "Dashboard", bundle: nil).instantiateViewController(identifier: "NCDashboardJobCandidatesViewController") as? NCDashboardJobCandidatesViewController else { return }
                    
                    viewController.responseModel = responseModel
                    self?.delegate?.navigate(viewController, .present)
                    
                } 
            }
        }
    }
    
}

extension NCDashboardView : NCDashboardViewModelDelegate {
    
    func showLoading(_ show: Bool) {
        delegate?.showLoading(show)
    }
    
    func dataFetched(_ success: Bool) {
        success ? reloadTableView() : tableView.setEmptyMessage("No Records Found.")

    }
    
}

extension NCDashboardView : NCDashboardJobDetailsViewControllerDelegate {
    
    func didApplyForJob(_ success: Bool) {
        
        if success {
            delegate?.refresh()
            viewModel?.fetchData()
        }
    }
    
}


