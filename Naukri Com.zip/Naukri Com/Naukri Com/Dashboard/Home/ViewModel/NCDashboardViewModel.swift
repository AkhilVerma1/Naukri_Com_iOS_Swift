//
//  NCDashboardViewModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation
import Alamofire

protocol NCDashboardViewModelDelegate :AnyObject {
    func showLoading(_ show:Bool)
    func dataFetched(_ success: Bool)
}

enum UserRole: Int {
    case recruiter = 0
    case candidate = 1
    
    init(_ value: Int) {
        if value == 0 { self = .recruiter}
        else { self = .candidate }
    }
}

class NCDashboardViewModel {
    
    weak var delegate: NCDashboardViewModelDelegate?
    
    private var signinMode: NSSignInResponseAPIModel?
    private var jobsResponseModel: NCJobsResponseModel?
    
    init(_ signinMode: NSSignInResponseAPIModel?) {
        
        self.signinMode = signinMode
        
        
//        if let siginModel_ = signinMode {
//            self.signinMode = siginModel_
//        } else {
//            self.signinMode = NCUserDefaults.getUserDefaults(NCUDConstants.signinModel) as? NSSignInResponseAPIModel
//        }
    }
    
    func fetchData() {
        
        switch getUserRole() {
        case .candidate:
            fetchAvaliableJobs()
        case .recruiter:
            fetchPostedJobs()
        }
    }
    
    func showAddPostButton() -> Bool {
        getUserRole() == .recruiter
    }
    
    func getUserRole() -> UserRole {
        UserRole(signinMode?.data?.userRole ?? 0)
    }
    
    func getTotalRows() -> Int {
        jobsResponseModel?.data?.count ?? 0
    }
    
    func getLocation(_ indexPath: IndexPath) -> String {
        jobsResponseModel?.data?[indexPath.row].location ?? ""
    }
    
    func getTitle(_ indexPath: IndexPath) -> String {
        jobsResponseModel?.data?[indexPath.row].title ?? ""
    }
    
    func getDescription(_ indexPath: IndexPath) -> String {
        jobsResponseModel?.data?[indexPath.row].datumDescription ?? ""
    }
    
    func createdAt(_ indexPath: IndexPath) -> String  {
        jobsResponseModel?.data?[indexPath.row].createdAt ?? ""
    }
    
    func getJobID(_ indexPath: IndexPath) -> String  {
        jobsResponseModel?.data?[indexPath.row].id ?? ""
    }
    
    func getToken()->String {
        signinMode?.data?.token ?? ""
    }
    
}

private extension NCDashboardViewModel {
    
    func fetchAvaliableJobs() {
        
        let url = NCAPIURL.Candidates.avaliableJob
        let headers : HTTPHeaders = ["Authorization" : self.signinMode?.data?.token ?? ""]
        
        delegate?.showLoading(true)
        
        AF.request(url, method: .get, headers: headers).response { [weak self] response in
            
            self?.delegate?.showLoading(false)
            
            guard let data_ = response.data else {
                self?.delegate?.dataFetched(false)
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                self?.jobsResponseModel = NCAvaliableJobsResponseModel(json)
                
                self?.delegate?.dataFetched(true)
            } catch {
                self?.delegate?.dataFetched(false)
            }
        }
        
    }
    
    func fetchPostedJobs() {
        
        let url = NCAPIURL.Recruiters.postedJobs
        let headers : HTTPHeaders = ["Authorization" : self.signinMode?.data?.token ?? ""]
        
        delegate?.showLoading(true)
        
        AF.request(url, method: .get, headers: headers).response { [weak self] response in
            
            self?.delegate?.showLoading(false)
            
            guard let data_ = response.data else {
                self?.delegate?.dataFetched(false)
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data_, options: .allowFragments) as? [AnyHashable:Any]
                self?.jobsResponseModel = NCPostedJobsResponseModel(json)
                
                self?.delegate?.dataFetched(true)
            } catch {
                self?.delegate?.dataFetched(false)
            }
        }
        
    }
    
}
