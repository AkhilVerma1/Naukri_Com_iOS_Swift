//
//  NCJobPostParamsModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation

struct NCJobPostParamsModel {
    var title: String?
    var description: String?
    var location: String?
    var token: String?
}
