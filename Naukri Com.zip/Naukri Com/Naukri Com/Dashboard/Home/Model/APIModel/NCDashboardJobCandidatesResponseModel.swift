//
//  NCDashboardJobCandidatesResponseModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation

class NCDashboardJobCandidatesResponseModel {
    
    var data = [NCDashboardJobCandidatesResponseModelData]()
    var success: Bool?
    var message: String?
    
    init(_ dict: [AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
     
        self.success = dict_["success"] as? Bool
        self.message = dict_["message"] as? String
        
        for data_ in dict_["data"] as? [[AnyHashable:Any]] ?? [] {
            self.data.append(NCDashboardJobCandidatesResponseModelData(data_))
        }
        
    }
    
}

class NCDashboardJobCandidatesResponseModelData {
    
    var email, name, skills, id: String?
    
    init(_ dict: [AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
        
        self.email = dict_["email"] as? String
        self.name = dict_["name"] as? String
        self.skills = dict_["skills"] as? String
        self.id = dict_["id"] as? String

    }
}




//"data": [
//    {
//        "email": "r478@gmail.com",
//        "name": "rgmail",
//        "skills": "c++ java sql",
//        "id": "a866c3bc-df67-4aa0-89c4-81975f64939b"
//    }
//],
//"code": 200,
//"success": true
//}
