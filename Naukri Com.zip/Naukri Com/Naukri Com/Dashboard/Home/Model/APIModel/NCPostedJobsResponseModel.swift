//
//  NCPostedJobsResponseModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation

class NCPostedJobsResponseModel: NCJobsResponseModel {

    var data : [NCAvaliableJobsResponseModelDatum]?
    var code: Int?
    var success: Bool?

    init(_ dict: [AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
        
        self.code = dict_["code"] as? Int
        self.success = dict_["success"] as? Bool

        data = [NCAvaliableJobsResponseModelDatum]()
        
        if let _data = dict_["data"] as? [AnyHashable:Any] {
            
            for data_ in _data["data"] as? [[AnyHashable:Any]] ?? [] {
                self.data?.append(NCAvaliableJobsResponseModelDatum(data_))
            }
        }
        
        
        
    }
}





