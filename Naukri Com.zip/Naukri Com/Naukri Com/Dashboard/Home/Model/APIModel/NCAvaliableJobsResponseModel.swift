//
//  NCAvaliableJobsResponseModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation

class NCAvaliableJobsResponseModel : NCJobsResponseModel {
    
    var data : [NCAvaliableJobsResponseModelDatum]?
    var code: Int?
    var success: Bool?

    init(_ dict: [AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
        
        self.code = dict_["code"] as? Int
        self.success = dict_["success"] as? Bool

        data = [NCAvaliableJobsResponseModelDatum]()
        
        for data_ in dict_["data"] as? [[AnyHashable:Any]] ?? [] {
            self.data?.append(NCAvaliableJobsResponseModelDatum(data_))
        }
        
    }
}

// MARK: - NCAvaliableJobsResponseModelDatum

class NCAvaliableJobsResponseModelDatum {
    
    var title, datumDescription, location, createdAt: String?
    var updatedAt, id: String?

    init(_ dict: [AnyHashable:Any]?) {
        
        guard let dict_ = dict else { return }
        
        self.title = dict_["title"] as? String
        self.datumDescription = dict_["description"] as? String
        self.location = dict_["location"] as? String
        self.createdAt = dict_["createdAt"] as? String
        self.updatedAt = dict_["updatedAt"] as? String
        self.id = dict_["id"] as? String
    }
}





