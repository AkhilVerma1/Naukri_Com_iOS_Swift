//
//  NCAvaliableJobsDetailsModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation

struct NCAvaliableJobsDetailsModel {
    var title:String?
    var description: String?
    var location: String?
    var createdAt: String?
    var jobID: String?
}
