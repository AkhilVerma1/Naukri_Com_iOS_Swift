//
//  NCJobsResponseModel.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import Foundation

protocol NCJobsResponseModel {
    var data : [NCAvaliableJobsResponseModelDatum]? { get set }
    var code: Int? { get set }
    var success: Bool? { get set }
}


