//
//  NCDashboardJobCandidatesViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import UIKit

class NCDashboardJobCandidatesViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var responseModel : NCDashboardJobCandidatesResponseModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    @IBAction func closeBtn(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}

private extension NCDashboardJobCandidatesViewController {
    
    func setupUI(){
        setupTableView()
        if responseModel?.data.count == 0 { tableView.setEmptyMessage("No Result found") }

        navigationController?.navigationBar.prefersLargeTitles = true
    }
    
    func setupTableView(){
    
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: NCDashboardJobCandidatesTableViewCell.nibName, bundle: nil), forCellReuseIdentifier: NCDashboardJobCandidatesTableViewCell.nibName)
    }
    
}

extension NCDashboardJobCandidatesViewController : UITableViewDataSource , UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        responseModel?.data.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let view = tableView.dequeueReusableCell(withIdentifier: NCDashboardJobCandidatesTableViewCell.nibName) as? NCDashboardJobCandidatesTableViewCell else { return UITableViewCell() }
        
        view.setData(email: responseModel?.data[indexPath.row].email, name: responseModel?.data[indexPath.row].name, skills: responseModel?.data[indexPath.row].skills)
        
        view.selectionStyle = .none
        return view
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        UIView()
    }
    
}
