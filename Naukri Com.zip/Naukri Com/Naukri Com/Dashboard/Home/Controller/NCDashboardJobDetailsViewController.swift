//
//  NCDashboardJobDetailsViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import UIKit

protocol NCDashboardJobDetailsViewControllerDelegate : AnyObject {
    func didApplyForJob(_ success: Bool)
}

class NCDashboardJobDetailsViewController: UIViewController {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var btnApplyJobOutlet: UIButton!
    
    var avaliableJobsDetailsModel: NCAvaliableJobsDetailsModel?
    var token: String?
    var disableApplyButton = false
    weak var delegate: NCDashboardJobDetailsViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    
    @IBAction func btnApplyJob(_ sender: Any) {
        
        NCDashboardJobDetailsFetcher.shared.applyToJob(avaliableJobsDetailsModel?.jobID, token: token) { [weak self] success in
            self?.setupApplyButton(success ?? false)
            self?.delegate?.didApplyForJob(success ?? false)
            
            if success ?? false {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self?.dismiss(animated: true, completion: nil)
                }
            }
        }
        
    }
    
}

private extension NCDashboardJobDetailsViewController {
    
    func setupUI() {
        lblLocation.text = avaliableJobsDetailsModel?.location
        lblTitle.text = avaliableJobsDetailsModel?.title
        lblDescription.text = avaliableJobsDetailsModel?.description
        lblTime.text =  NCUtility.utcStr(toLocalStr: avaliableJobsDetailsModel?.createdAt, inputFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSSSSS'Z'", outputFormat: "d MMMM, yyyy 'at' hh:mm a")
        
        btnApplyJobOutlet.layer.borderWidth = 2
        btnApplyJobOutlet.layer.cornerRadius = 15
        btnApplyJobOutlet.layer.borderColor = UIColor.systemBlue.cgColor
        
        if disableApplyButton {
            setupApplyButton(true)
        }
        
    }
    
    func setupApplyButton(_ success: Bool) {
        self.btnApplyJobOutlet.setTitle(success ? "Applied": "Error Occured", for: .normal)
        self.btnApplyJobOutlet.setTitleColor(success ? .systemGreen : .systemRed, for: .normal)
        self.btnApplyJobOutlet.layer.borderColor = success ? UIColor.systemGreen.cgColor : UIColor.systemRed.cgColor
        self.btnApplyJobOutlet.isEnabled = !success
    }
    
}





