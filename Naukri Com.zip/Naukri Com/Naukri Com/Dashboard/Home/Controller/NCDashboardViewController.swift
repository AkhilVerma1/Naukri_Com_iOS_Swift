//
//  NCDashboardViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import UIKit
import Lottie

protocol NCDashboardViewControllerDelegate: AnyObject {
    func refreshView()
}

class NCDashboardViewController: UIViewController, NCDashboard {
    
    @IBOutlet weak var uvContainer: UIView!
    @IBOutlet weak var btnPostJobOutlet: UIBarButtonItem!
    @IBOutlet weak var animationView: AnimationView!
    
    private var spinner: NCSpinner?
    private var viewModel : NCDashboardViewModel?
    weak var delegate: NCDashboardViewControllerDelegate?
    
    var userSigninResponseModel : NSSignInResponseAPIModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated:true)
        initializeView()
    }
    
    @IBAction func btnAddJobPost(_ sender: Any) {
        
        guard let viewController = UIStoryboard(name: "Dashboard", bundle: nil).instantiateViewController(identifier: "NCDashboardPostJobViewController") as? NCDashboardPostJobViewController else { return }
        
        viewController.delegate = self
        viewController.token = userSigninResponseModel?.data?.token
        self.present(viewController, animated: true, completion: nil)
       
    }
    
    @IBAction func btnLogout(_ sender: Any) {
        
        let alertViewController = UIAlertController(title: "Logout", message: "Do you want to logout?", preferredStyle: .alert)
        
        let logoutAction = UIAlertAction(title: "Logout", style: .default) { [weak self] action in
            self?.logout()
        }
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { _IOFBF in
            alertViewController.dismiss(animated: true, completion: nil)
        }
        
        alertViewController.addAction(logoutAction)
        alertViewController.addAction(cancel)
        
        self.present(alertViewController, animated: true, completion: nil)
        
    }

}

private extension NCDashboardViewController {

    func initializeView(){
        let dashboardView = NCDashboardView(frame: self.uvContainer.bounds)
        dashboardView.delegate = self
        viewModel = getViewModel()
        dashboardView.setupViewModel(viewModel)
        uvContainer.addSubview(dashboardView)
        NCUtility.addPinnedContraints(subView: dashboardView, parentView: self.uvContainer)
        
        btnPostJobOutlet.isHidden = !(viewModel?.showAddPostButton() ?? false)
        setupAnimation()
    }
    
    func getViewModel() -> NCDashboardViewModel {
        NCDashboardViewModel(userSigninResponseModel)
    }
    
    func setupAnimation(){
        animationView.contentMode = .scaleToFill
        animationView.loopMode = .loop
        animationView.animationSpeed = 0.9
        animationView.play()
        
    }
    
    func logout() {
        
        guard let startViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "NCStartScreenViewController") as? NCStartScreenViewController else { return }
        
        DispatchQueue.main.async {
            if let _topController = UIApplication.topViewController()  {
                
                let _controller = startViewController
                
                let navigationController = UINavigationController(rootViewController: _controller)
                
                navigationController.modalPresentationStyle = .fullScreen
                navigationController.isNavigationBarHidden = false
                navigationController.navigationBar.prefersLargeTitles = true
                
                _topController.present(navigationController, animated: true, completion: nil)
            }
        }

        NCUserDefaults.clearDataOnLogout()

    }
    
}

extension NCDashboardViewController : NCDashboardViewDelegate {
    
    func refresh() {
        delegate?.refreshView()
    }
    
    func navigate(_ viewController: UIViewController, _ present: PresentationMode) {
        switch present {
        case .present:
            self.present(viewController, animated: true, completion: nil)
        case .push:
            navigationController?.pushViewController(viewController, animated: true)
        }
    }
    
    func showLoading(_ show: Bool) {
        if show {
            animationView.play()
            animationView.isHidden = false
        } else {
            animationView.pause()
            animationView.isHidden = true
        }
    }
    
}

extension NCDashboardViewController : NCDashboardPostJobViewControllerDelegate {
    
    func didPostJob(_ success: Bool) {
        if success {
            viewModel?.fetchData()
        }
    }
    
}
