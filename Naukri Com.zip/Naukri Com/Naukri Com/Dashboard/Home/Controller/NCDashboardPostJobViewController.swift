//
//  NCDashboardPostJobViewController.swift
//  Naukri Com
//
//  Created by Akhil Verma on 30/08/21.
//

import UIKit

protocol NCDashboardPostJobViewControllerDelegate : AnyObject {
    func didPostJob(_ success: Bool)
}

class NCDashboardPostJobViewController: UIViewController {
    
    @IBOutlet weak var tfTitle: UITextField!
    @IBOutlet weak var tvDescription: UITextView!
    @IBOutlet weak var tfLocation: UITextField!
    @IBOutlet weak var btnPostJobOutlet: UIButton!
    @IBOutlet weak var lblError: UILabel!
    
    weak var delegate: NCDashboardPostJobViewControllerDelegate?
    var token: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    @IBAction func btnPostJob(_ sender: Any) {
        
        if let error = getCustomError() {
            lblError.text = error
        } else {
            lblError.text = nil
            postJob()
        }
        
    }
    
}

private extension NCDashboardPostJobViewController {
    
    func setupUI(){
        btnPostJobOutlet.layer.borderWidth = 2
        btnPostJobOutlet.layer.cornerRadius = 15
        btnPostJobOutlet.layer.borderColor = UIColor.systemBlue.cgColor
        tfTitle.becomeFirstResponder()
        
        lblError.text = nil
    }
    
    func postJob(){
        NCDashboardJobDetailsFetcher.shared.createJob(NCJobPostParamsModel(title: tfTitle.text, description: tvDescription.text, location: tfLocation.text, token: token)) { [weak self] success, message, error in
            
            self?.delegate?.didPostJob(success ?? false)
            
            if success ?? false {
                self?.btnPostJobOutlet.layer.borderColor = UIColor.systemGreen.cgColor
                self?.btnPostJobOutlet.setTitle("Job Posted", for: .normal)
                self?.btnPostJobOutlet.setTitleColor(UIColor.systemGreen, for: .normal)
                self?.btnPostJobOutlet.isEnabled = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    self?.dismiss(animated: true, completion: nil)
                }
                
            } else {
                self?.handleAPIException(error, message: message)
                self?.btnPostJobOutlet.layer.borderColor = UIColor.systemRed.cgColor
                self?.btnPostJobOutlet.setTitle("Error Occured", for: .normal)
                self?.btnPostJobOutlet.setTitleColor(UIColor.systemRed, for: .normal)
            }
        }
    }
    
    
    func handleAPIException(_ errors: [[String:String]]?, message: String?){
        
        guard let errors_ = errors else {
            self.lblError.text = message ?? "Something went wrong."
            return
        }
        
        for error in errors_ {
            if let err = error.values.first {
                lblError.text = "\(lblError.text ?? "") \(err) \n"
            }
        }
        
    }
    
    func getCustomError() -> String? {
        
        if NCUtility.isNilOrEmpty(string: tfTitle.text) {
            return "Please enter a title."
        }
        
        if NCUtility.isNilOrEmpty(string: tvDescription.text) {
            return "please enter a description"
        }
        
        if NCUtility.isNilOrEmpty(string: tfLocation.text) {
            return "pleae enter a location"
        }
        
        return nil
        
    }
    
}

