//
//  NCAPIURL.swift
//  Naukri Com
//
//  Created by Akhil Verma on 28/08/21.
//

import Foundation

struct NCAPIURL {
    
    struct Login {
        static let authenticate = getBaseURL() + "auth/login"
        static let register = getBaseURL() + "auth/register"
        static let changePassword = getBaseURL() + "auth/resetpassword"

        static func getResetPasswordToken(_ emailID: String) -> String {
            getBaseURL() + "auth/resetpassword?email=\(emailID)"
        }
       
        static func getverifyPassword(_ token: String) -> String {
            getBaseURL() + "auth/resetpassword/\(token)"
        }
    }
    
    struct Jobs {
        static let createJob = getBaseURL() + "jobs/"
        static let getAllJobs = getBaseURL() + "jobs"
        static let deleteJob = getBaseURL() + "jobs"
        
        static func getJobDetails(_ id: String) -> String {
            getBaseURL() + "jobs/\(id)"
        }
    }
    
    struct Candidates {
        static let applyForJob = getBaseURL() + "candidates/jobs"
        static let avaliableJob = getBaseURL() + "candidates/jobs"
        static let alreadyAppliedJob = getBaseURL() + "candidates/jobs/applied"
        
    }
    
    struct Recruiters {
        static let postedJobs = getBaseURL() + "recruiters/jobs"
        
        static func getOneJobCandidates(_ id: String) -> String{
            getBaseURL() + "recruiters/jobs/\(id)/candidates"
        }
    }
    
}

private extension NCAPIURL {
    
    static func getBaseURL() -> String {
        "https://jobs-api.squareboat.info/api/v1/"
    }
    
}
